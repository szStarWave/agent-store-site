# tc-chengxin-cli

同程程心接入 WorkBuddy「连应用」的 **CLI 连接器（鉴权端）**。

本 CLI **只负责 OAuth 鉴权与 token 维护**。旅行资源查询脚本（`*-query.js`）**随连接器的 skill 一起下发**（在连接器包 `skills/scripts/` 内），不再由 CLI 携带；查询时由 Skill 用 `export CHENGXIN_API_KEY="$(tc-chengxin token)"` 注入令牌后直接 `node scripts/x-query.js` 调用。

## 设计要点

- 授权采用「设备码式轮询」：CLI 调用网关 `/api/v1/oauth/cli/start` 拿到同程授权 URL，OAuth 回调由**网关**接收（CLI 不本地起服务、不持有 client_secret）。
- token 与续期由 CLI 本地维护：`auth status` / `token` 时若 access 临期会用 `refresh_token` 静默续期。
- CLI 不维护 skill 与查询脚本（这部分属于 skill 本身）。

## 命令

| 命令 | 说明 |
|------|------|
| `tc-chengxin auth login [--no-wait --json]` | 发起同程登录授权；`--no-wait --json` 打印授权 URL（JSON）后退出（WorkBuddy 模式） |
| `tc-chengxin auth status [--json]` | 查看登录状态，必要时静默续期或轮询；`--json` 输出 `{"authenticated":true/false}` |
| `tc-chengxin auth logout` | 撤销并清除本地凭证 |
| `tc-chengxin token` | 打印当前有效 access_token（必要时自动续期）；未登录则非零退出。供 Skill `export CHENGXIN_API_KEY="$(tc-chengxin token)"` 使用 |
| `tc-chengxin --version` | 版本号 |

## 本地文件

- `~/.tc-chengxin/credentials.json` — 登录凭证（access/refresh/expire/user）
- `~/.tc-chengxin/session.json` — 进行中的授权会话
- `~/.tc-chengxin/cli-config.json` — 网关地址（`gatewayBase`，本地联调用）

## 配置

- 网关地址优先级：环境变量 `TC_GATEWAY_BASE` > `~/.tc-chengxin/cli-config.json` 的 `gatewayBase` > 默认。
- 默认网关由打包时的环境配置生成，环境地址维护在 `config/gateway-env.json`。
- 发布生产包使用 `npm run pack:product` 或 `CLI_BUILD_ENV=product npm pack`。
- 发布 stage 包使用 `npm run pack:stage` 或 `CLI_BUILD_ENV=stage npm pack`。
- 本地联调包使用 `npm run pack:local`，也可以写入 `~/.tc-chengxin/cli-config.json` 临时覆盖。
- 发布前检查 `src/runtime-config.json`，不要把 `local` 地址带入生产包。

## 安装

```bash
# 本地安装（使 tc-chengxin 上 PATH，免发布）
npm install -g .
```

## 发布

CLI 的环境地址、打包和发布流程见 [docs/release.md](docs/release.md)。
